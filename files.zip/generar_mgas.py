import sys, json
from openpyxl import Workbook
from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                              GradientFill)
from openpyxl.utils import get_column_letter

def thin():
    s = Side(style='thin', color='BFBFBF')
    return Border(left=s, right=s, top=s, bottom=s)

def thick_bottom():
    return Border(bottom=Side(style='medium', color='2E75B6'))

def fill(hex_color):
    return PatternFill('solid', start_color=hex_color, fgColor=hex_color)

def style_header(cell, bg='2E75B6', fg='FFFFFF', bold=True, size=9, wrap=False, halign='center'):
    cell.font = Font(bold=bold, color=fg, size=size, name='Arial')
    cell.fill = fill(bg)
    cell.alignment = Alignment(horizontal=halign, vertical='center', wrap_text=wrap)
    cell.border = thin()

def style_eas_header(cell):
    cell.font = Font(bold=True, color='1F3864', size=8.5, name='Arial')
    cell.fill = fill('D6E4F0')
    cell.alignment = Alignment(horizontal='left', vertical='center', wrap_text=False)
    cell.border = thin()

def style_data(cell, wrap=False, halign='left', bold=False, bg=None, fg='000000', size=8):
    cell.font = Font(bold=bold, color=fg, size=size, name='Arial')
    cell.alignment = Alignment(horizontal=halign, vertical='center', wrap_text=wrap)
    cell.border = thin()
    if bg:
        cell.fill = fill(bg)

def style_calc(cell):
    cell.font = Font(bold=True, color='1F3864', size=8, name='Arial')
    cell.fill = fill('EBF3FB')
    cell.alignment = Alignment(horizontal='center', vertical='center')
    cell.border = thin()

INDICADORES = [
    {'eas': 'EAS-1', 'label': 'EAS-1: Evaluación y gestión de riesgos e impactos ambientales y sociales'},
    {'n':1,'act':'Gestión Ambiental en ANP','ind':'N° de informes de seguimiento a ≥10% de proyectos habilitados (construcción, operación o cierre)','u':'Informe','mv':'Informe de seguimiento a los proyectos'},
    {'n':2,'act':'Gestión Ambiental en ANP','ind':'N° de infraestructuras con conformidad y compatibilidad de la DGANP','u':'Infraestructura','mv':'Informe DGANP que otorga la conformidad y compatibilidad'},
    {'eas': 'EAS-2', 'label': 'EAS-2: Trabajo y condiciones laborales — Guardaparques y personal ANP'},
    {'n':3,'act':'Vigilancia y Control','ind':'Capacitaciones en prevención de riesgos laborales (puesto de trabajo)','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':4,'act':'Vigilancia y Control','ind':'Capacitaciones sobre patrullajes acuáticos','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':5,'act':'Vigilancia y Control','ind':'Capacitaciones sobre patrullajes terrestres','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':6,'act':'Vigilancia y Control','ind':'Capacitaciones sobre hallazgos y avistamientos de PIACI','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':7,'act':'Vigilancia y Control','ind':'Reportes de hallazgos/avistamientos de PIACI enviados a MINCUL','u':'Reporte','mv':'Reportes enviados a MINCUL'},
    {'n':8,'act':'Vigilancia y Control','ind':'Capacitaciones en rescate de alta montaña / alta mar / vía fluvial','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':9,'act':'Vigilancia y Control','ind':'Puestos de vigilancia con números de emergencia visibles','u':'Puesto de Vigilancia','mv':'Foto del número de emergencia en el PVC'},
    {'n':10,'act':'Vigilancia y Control','ind':'Puestos de vigilancia con flujograma de comunicación visible','u':'Puesto de Vigilancia','mv':'Foto del flujograma en el PVC'},
    {'n':11,'act':'Vigilancia y Control','ind':'Capacitaciones en primeros auxilios','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':12,'act':'Vigilancia y Control','ind':'Puestos de vigilancia con botiquín de primeros auxilios equipado','u':'Puesto de Vigilancia','mv':'Foto del botiquín en el PVC'},
    {'n':13,'act':'Vigilancia y Control','ind':'Capacitaciones sobre conducción de vehículos / embarcaciones','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':14,'act':'Vigilancia y Control','ind':'Capacitaciones sobre riesgos biológicos (vectores)','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':15,'act':'Vigilancia y Control','ind':'Capacitaciones en los procesos de intervención','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':16,'act':'Vigilancia y Control','ind':'Capacitaciones para prevenir y tratar mordeduras de reptiles u otros animales','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'eas': 'EAS-3', 'label': 'EAS-3: Eficiencia en el uso de recursos y gestión de contaminación'},
    {'n':17,'act':'Gestión Ambiental','ind':'Capacitaciones al personal sobre manejo de residuos sólidos','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':18,'act':'Gestión Ambiental','ind':'Planes de gestión de residuos sólidos elaborados/actualizados','u':'Plan','mv':'Plan aprobado por la DGANP'},
    {'n':19,'act':'Gestión Ambiental','ind':'Informes trimestrales de gestión de residuos sólidos','u':'Informe','mv':'4 informes trimestrales'},
    {'eas': 'EAS-4', 'label': 'EAS-4: Salud y seguridad de la comunidad — Turismo y aprovechamiento'},
    {'n':20,'act':'Turismo','ind':'Capacitaciones en identificación de peligros/riesgos en rutas turísticas','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':21,'act':'Turismo','ind':'Capacitaciones en primeros auxilios para emergencias turísticas','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':22,'act':'Turismo','ind':'Señaléticas instaladas para prevenir accidentes en el ANP','u':'Señalética','mv':'Fotos de señaléticas instaladas'},
    {'n':23,'act':'Turismo','ind':'Planes de Sitio con medidas/normas de seguridad','u':'Plan de Sitio','mv':'Plan de Sitio aprobado'},
    {'n':24,'act':'Turismo','ind':'Capacitaciones a operadores de turismo sobre riesgos del ANP','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':25,'act':'Turismo','ind':'Capacitaciones a visitantes para prevenir accidentes en el ANP','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'n':26,'act':'Recursos Naturales','ind':'Planes de Manejo de Recursos con recomendaciones de seguridad','u':'Plan de Manejo','mv':'Plan aprobado'},
    {'n':27,'act':'Recursos Naturales','ind':'Capacitaciones a usuarios de aprovechamiento sobre medidas de seguridad','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'eas': 'EAS-5', 'label': 'EAS-5: Adquisición de tierras y restricciones sobre uso de la tierra'},
    {'n':28,'act':'Consulta y Participación','ind':'Talleres de consulta previa por cambio de zonificación o establecimiento de nuevas ANP','u':'Taller','mv':'Informe con lista de asistencia, fotos'},
    {'n':29,'act':'Consulta y Participación','ind':'Actas de reuniones descentralizadas con PI y comunidades (zonificación, Planes Maestros)','u':'Actas','mv':'Carpeta con actas de todas las reuniones'},
    {'n':30,'act':'Acciones Comunicativas','ind':'Actividades comunicativas en consulta previa (enfoque intercultural, intergeneracional, género)','u':'Acción','mv':'Fotos, flyers, links de publicación'},
    {'eas': 'EAS-7', 'label': 'EAS-7: Pueblos indígenas / comunidades locales tradicionales'},
    {'n':31,'act':'Consulta y Participación','ind':'Informes del Mapa de Actores con identificación de PI y comunidades locales','u':'Informe semestral','mv':'Informe del Mapa de Actores'},
    {'n':32,'act':'Consulta y Participación','ind':'Actas de reuniones en espacios/mecanismos participativos con PI (CG, AdC, VC, GPV, ECA)','u':'Actas','mv':'Carpeta con actas de todas las reuniones'},
    {'n':33,'act':'Acciones Comunicativas','ind':'Actividades comunicativas con actores (enfoque intercultural, intergeneracional, género)','u':'Acción','mv':'Fotos, flyers, links de publicación'},
    {'eas': 'EAS-8', 'label': 'EAS-8: Patrimonio cultural — Saberes ancestrales y PIACI'},
    {'n':34,'act':'Enfoque Intercultural','ind':'Informes de recopilación de saberes ancestrales','u':'Informe','mv':'Informe de recopilación'},
    {'n':35,'act':'Enfoque Intercultural','ind':'Plan de Contingencia Antropológica para PIACI aprobado e implementado','u':'Documento','mv':'Documento aprobado e implementado'},
    {'n':36,'act':'Enfoque Intercultural','ind':'Capacitaciones sobre enfoque intercultural al personal del ANP','u':'Capacitación','mv':'Lista de asistencia, fotos'},
    {'eas': 'EAS-10', 'label': 'EAS-10: Participación de partes involucradas y divulgación de información'},
    {'n':37,'act':'Sistematización','ind':'Reportes de alerta de conflictos socioambientales en el ANP y ZA (RATCS)','u':'Reporte','mv':'Informe o Reporte'},
    {'n':38,'act':'Sistematización','ind':'Registros del MAQS (Mecanismo de Atención de Quejas, Consultas y Sugerencias)','u':'Reporte','mv':'Informe o Reporte MAQS'},
    {'n':39,'act':'Participación','ind':'Capacitaciones al personal en uso y gestión del MAQS','u':'Capacitación','mv':'Lista de asistencia, fotos'},
]

def generar(data, outpath):
    p = data.get('portada', {})
    ejecucion = data.get('ejecucion', {})
    conclusiones = data.get('conclusiones', {})
    medios = data.get('medios', {})

    wb = Workbook()

    # ── HOJA 1: PORTADA ────────────────────────────────────────────────────────
    ws1 = wb.active
    ws1.title = 'PORTADA'
    ws1.sheet_view.showGridLines = False

    ws1.column_dimensions['A'].width = 3
    ws1.column_dimensions['B'].width = 32
    ws1.column_dimensions['C'].width = 22
    ws1.column_dimensions['D'].width = 22
    ws1.column_dimensions['E'].width = 22
    ws1.column_dimensions['F'].width = 4

    # Título principal
    ws1.merge_cells('B1:E1')
    c = ws1['B1']
    c.value = 'REPORTE TRIMESTRAL DE SALVAGUARDAS — MGAS-SERNANP'
    c.font = Font(bold=True, size=13, color='FFFFFF', name='Arial')
    c.fill = fill('1F3864')
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws1.row_dimensions[1].height = 28

    # Subtítulo
    ws1.merge_cells('B2:E2')
    c = ws1['B2']
    c.value = f"EAS 1, 2, 3, 4, 5, 7, 8, 10 — Banco Mundial  |  REDD+ Perú"
    c.font = Font(size=9, color='FFFFFF', name='Arial')
    c.fill = fill('2E75B6')
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws1.row_dimensions[2].height = 16

    ws1.row_dimensions[3].height = 10

    # Sección datos generales
    ws1.merge_cells('B4:E4')
    c = ws1['B4']
    c.value = 'I.  DATOS DE IDENTIFICACIÓN DEL PROYECTO Y ANP'
    c.font = Font(bold=True, size=9, color='1F3864', name='Arial')
    c.fill = fill('D6E4F0')
    c.alignment = Alignment(horizontal='left', vertical='center')
    ws1.row_dimensions[4].height = 16

    campos = [
        ('B5','Nombre del Proyecto REDD+:','D5', p.get('nombre','')),
        ('B6','Área Natural Protegida (ANP):','D6', p.get('anp','')),
        ('B7','Categoría de Manejo:','D7', p.get('categoria','')),
        ('B8','Entidad Ejecutora / UCP:','D8', p.get('entidad','')),
        ('B9','Dependencia SERNANP:','D9', p.get('dependencia','')),
        ('B10','Jefe(a) de ANP:','D10', p.get('jefe','')),
        ('B11','Punto Focal de Salvaguardas:','D11', p.get('focal','')),
        ('B12','Responsable del Reporte:','D12', p.get('responsable','')),
    ]
    campos_der = [
        ('C5','Código del Proyecto:','E5', p.get('codigo_proyecto','')),
        ('C6','Código ANP (SERNANP):','E6', p.get('codigo_anp','')),
        ('C7','Año del Reporte:','E7', str(p.get('anio',''))),
        ('C8','Trimestre:','E8', p.get('trimestre','')),
        ('C9','Período — Desde:','E9', p.get('periodo_desde','')),
        ('C10','Fecha de elaboración:','E10', p.get('fecha_elaboracion','')),
        ('C11','N° de Reporte:','E11', p.get('nro_reporte','')),
        ('C12','Versión:','E12', p.get('version','')),
    ]

    for r,(lc,lt,vc,vv) in enumerate(campos, 5):
        lbl = ws1[lc]
        lbl.value = lt
        lbl.font = Font(bold=True, size=8, color='2E75B6', name='Arial')
        lbl.alignment = Alignment(horizontal='left', vertical='center')
        ws1.merge_cells(f'{vc}:{vc[0]}{vc[1:]}') if False else None
        val = ws1[vc]
        val.value = vv
        val.font = Font(size=8, name='Arial')
        val.alignment = Alignment(horizontal='left', vertical='center')
        val.border = Border(bottom=Side(style='thin', color='2E75B6'))
        ws1.row_dimensions[r].height = 16

    for r,(lc,lt,vc,vv) in enumerate(campos_der, 5):
        lbl = ws1[lc]
        lbl.value = lt
        lbl.font = Font(bold=True, size=8, color='2E75B6', name='Arial')
        lbl.alignment = Alignment(horizontal='right', vertical='center')
        val = ws1[vc]
        val.value = vv
        val.font = Font(size=8, name='Arial')
        val.alignment = Alignment(horizontal='left', vertical='center')
        val.border = Border(bottom=Side(style='thin', color='2E75B6'))

    ws1.row_dimensions[13].height = 10
    ws1.merge_cells('B14:E14')
    c = ws1['B14']
    c.value = 'Período de reporte:  Desde: ' + p.get('periodo_desde','__________') + '    Hasta: ' + p.get('periodo_hasta','__________')
    c.font = Font(size=8, name='Arial', italic=True, color='595959')
    c.alignment = Alignment(horizontal='left', vertical='center')
    ws1.row_dimensions[14].height = 14

    # ── HOJA 2: EJECUCIÓN TRIMESTRAL MGAS ──────────────────────────────────────
    ws2 = wb.create_sheet('EJECUCIÓN TRIMESTRAL MGAS')
    ws2.sheet_view.showGridLines = False

    ws2.column_dimensions['A'].width = 4   # N°
    ws2.column_dimensions['B'].width = 18  # EAS / Actividad
    ws2.column_dimensions['C'].width = 36  # Indicador
    ws2.column_dimensions['D'].width = 14  # Unidad
    ws2.column_dimensions['E'].width = 10  # Meta anual
    ws2.column_dimensions['F'].width = 8   # I Trim
    ws2.column_dimensions['G'].width = 8   # II Trim
    ws2.column_dimensions['H'].width = 8   # III Trim
    ws2.column_dimensions['I'].width = 8   # IV Trim
    ws2.column_dimensions['J'].width = 11  # Total
    ws2.column_dimensions['K'].width = 10  # Avance %
    ws2.column_dimensions['L'].width = 28  # Medio verificación

    # Título hoja
    ws2.merge_cells('A1:L1')
    c = ws2['A1']
    c.value = 'EJECUCIÓN TRIMESTRAL DE MEDIDAS — MGAS-SERNANP  |  EAS 1, 2, 3, 4, 5, 7, 8, 10 — Banco Mundial'
    c.font = Font(bold=True, size=10, color='FFFFFF', name='Arial')
    c.fill = fill('1F3864')
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws2.row_dimensions[1].height = 22

    ws2.row_dimensions[2].height = 6

    # Cabecera de tabla
    headers = ['N°','EAS / Actividad','Indicador / Medida','Unidad de medida','Meta anual','I Trim.','II Trim.','III Trim.','IV Trim.','Total\nejecutado','Avance %','Medio de verificación']
    for col, h in enumerate(headers, 1):
        c = ws2.cell(row=3, column=col, value=h)
        style_header(c, wrap=True, size=8)
    ws2.row_dimensions[3].height = 28

    # Filas de datos
    excel_row = 4
    data_rows = []  # (excel_row, n) for formula building

    for item in INDICADORES:
        if 'eas' in item:
            ws2.merge_cells(f'A{excel_row}:L{excel_row}')
            c = ws2[f'A{excel_row}']
            c.value = '  ' + item['label']
            style_eas_header(c)
            ws2.row_dimensions[excel_row].height = 14
            excel_row += 1
        else:
            n = item['n']
            key = str(n)
            ev = ejecucion.get(key, {})
            meta = ev.get('meta', 0) or 0
            t1 = ev.get('t1', 0) or 0
            t2 = ev.get('t2', 0) or 0
            t3 = ev.get('t3', 0) or 0
            t4 = ev.get('t4', 0) or 0

            row_vals = [n, item['act'], item['ind'], item['u'], meta, t1, t2, t3, t4]
            for col, v in enumerate(row_vals, 1):
                c = ws2.cell(row=excel_row, column=col, value=v)
                if col == 1:
                    style_data(c, halign='center', fg='595959')
                elif col == 2:
                    style_data(c, fg='404040', size=7.5)
                elif col == 3:
                    style_data(c, wrap=True, size=7.5)
                    ws2.row_dimensions[excel_row].height = 30
                elif col == 4:
                    style_data(c, halign='center', size=7.5, fg='404040')
                else:
                    style_data(c, halign='center', bold=(col==5))

            # Fórmulas calculadas
            c_total = ws2.cell(row=excel_row, column=10)
            c_total.value = f'=SUM(F{excel_row}:I{excel_row})'
            style_calc(c_total)

            c_pct = ws2.cell(row=excel_row, column=11)
            c_pct.value = f'=IF(E{excel_row}=0,0,J{excel_row}/E{excel_row})'
            c_pct.number_format = '0.0%'
            style_calc(c_pct)

            c_mv = ws2.cell(row=excel_row, column=12)
            mv_link = medios.get(key, {}).get('link', '') or item['mv']
            c_mv.value = mv_link
            style_data(c_mv, wrap=True, size=7, fg='595959')

            data_rows.append(excel_row)
            excel_row += 1

    # Fila TOTAL
    ws2.merge_cells(f'A{excel_row}:I{excel_row}')
    c = ws2[f'A{excel_row}']
    c.value = 'NIVEL DE AVANCE TOTAL (suma de ejecución trimestral)'
    c.font = Font(bold=True, size=8, color='FFFFFF', name='Arial')
    c.fill = fill('2E75B6')
    c.alignment = Alignment(horizontal='left', vertical='center')

    total_refs = '+'.join([f'J{r}' for r in data_rows])
    c_total_final = ws2.cell(row=excel_row, column=10)
    c_total_final.value = f'=SUM({",".join([f"J{r}" for r in data_rows])})'
    c_total_final.font = Font(bold=True, size=9, color='FFFFFF', name='Arial')
    c_total_final.fill = fill('2E75B6')
    c_total_final.alignment = Alignment(horizontal='center', vertical='center')

    ws2.merge_cells(f'K{excel_row}:L{excel_row}')
    c2 = ws2[f'K{excel_row}']
    c2.font = Font(bold=True, size=8, color='FFFFFF', name='Arial')
    c2.fill = fill('2E75B6')
    ws2.row_dimensions[excel_row].height = 16

    # ── HOJA 3: CONCLUSIONES Y FIRMAS ──────────────────────────────────────────
    ws3 = wb.create_sheet('CONCLUSIONES Y FIRMAS')
    ws3.sheet_view.showGridLines = False
    ws3.column_dimensions['A'].width = 3
    ws3.column_dimensions['B'].width = 85
    ws3.column_dimensions['C'].width = 4

    ws3.merge_cells('B1:B1')
    c = ws3['B1']
    c.value = 'CONCLUSIONES, LECCIONES APRENDIDAS Y COMPROMISOS PARA EL SIGUIENTE TRIMESTRE'
    c.font = Font(bold=True, size=10, color='FFFFFF', name='Arial')
    c.fill = fill('1F3864')
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws3.row_dimensions[1].height = 22

    secciones = [
        ('Síntesis del estado de cumplimiento de salvaguardas del trimestre', conclusiones.get('sintesis','')),
        ('Principales logros vs. trimestre anterior', conclusiones.get('logros','')),
        ('Lecciones aprendidas y buenas prácticas a escalar', conclusiones.get('lecciones','')),
        ('Compromisos y metas para el siguiente trimestre', conclusiones.get('compromisos','')),
        ('Recomendaciones al SERNANP / financiadores', conclusiones.get('recomendaciones','')),
    ]

    row = 2
    for titulo, contenido in secciones:
        ws3.row_dimensions[row].height = 6
        row += 1
        c = ws3.cell(row=row, column=2, value='  ' + titulo)
        c.font = Font(bold=True, size=8.5, color='1F3864', name='Arial')
        c.fill = fill('D6E4F0')
        c.alignment = Alignment(horizontal='left', vertical='center')
        ws3.row_dimensions[row].height = 14
        row += 1
        c = ws3.cell(row=row, column=2, value=contenido or '')
        c.font = Font(size=8.5, name='Arial')
        c.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
        c.border = Border(
            left=Side(style='thin', color='BDD7EE'),
            right=Side(style='thin', color='BDD7EE'),
            top=Side(style='thin', color='BDD7EE'),
            bottom=Side(style='thin', color='BDD7EE'),
        )
        ws3.row_dimensions[row].height = 48
        row += 1

    # Firmas
    ws3.row_dimensions[row].height = 10
    row += 1
    ws3.merge_cells(f'B{row}:B{row}')
    c = ws3[f'B{row}']
    c.value = 'FIRMAS DE CONFORMIDAD'
    c.font = Font(bold=True, size=9, color='FFFFFF', name='Arial')
    c.fill = fill('2E75B6')
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws3.row_dimensions[row].height = 16

    # ── HOJA 4: MEDIOS DE VERIFICACIÓN ─────────────────────────────────────────
    ws4 = wb.create_sheet('MEDIOS DE VERIFICACIÓN')
    ws4.sheet_view.showGridLines = False
    ws4.column_dimensions['A'].width = 4
    ws4.column_dimensions['B'].width = 16
    ws4.column_dimensions['C'].width = 34
    ws4.column_dimensions['D'].width = 22
    ws4.column_dimensions['E'].width = 40
    ws4.column_dimensions['F'].width = 14

    ws4.merge_cells('A1:F1')
    c = ws4['A1']
    c.value = 'CATÁLOGO DE MEDIOS DE VERIFICACIÓN  |  Registrar el link / ruta de archivo por cada indicador reportado'
    c.font = Font(bold=True, size=9, color='FFFFFF', name='Arial')
    c.fill = fill('1F3864')
    c.alignment = Alignment(horizontal='center', vertical='center')
    ws4.row_dimensions[1].height = 18

    mv_headers = ['N°','EAS / Salvaguarda','Indicador','Tipo de evidencia','Link / Ruta al documento','Fecha del documento']
    for col, h in enumerate(mv_headers, 1):
        c = ws4.cell(row=2, column=col, value=h)
        style_header(c, size=8)
    ws4.row_dimensions[2].height = 16

    row4 = 3
    for item in INDICADORES:
        if 'eas' in item:
            continue
        n = item['n']
        key = str(n)
        mv_data = medios.get(key, {})
        link = mv_data.get('link', '')
        fecha = mv_data.get('fecha', '')

        ws4.cell(row=row4, column=1, value=n).font = Font(size=7.5, name='Arial', color='595959')
        ws4.cell(row=row4, column=1).alignment = Alignment(horizontal='center', vertical='center')
        ws4.cell(row=row4, column=1).border = thin()

        ws4.cell(row=row4, column=2, value=item['act']).font = Font(size=7.5, name='Arial')
        ws4.cell(row=row4, column=2).alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
        ws4.cell(row=row4, column=2).border = thin()

        ws4.cell(row=row4, column=3, value=item['ind']).font = Font(size=7.5, name='Arial')
        ws4.cell(row=row4, column=3).alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
        ws4.cell(row=row4, column=3).border = thin()

        ws4.cell(row=row4, column=4, value=item['mv']).font = Font(size=7.5, name='Arial', color='595959')
        ws4.cell(row=row4, column=4).alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
        ws4.cell(row=row4, column=4).border = thin()

        c_link = ws4.cell(row=row4, column=5, value=link)
        c_link.font = Font(size=7.5, name='Arial', color='185FA5', underline='single' if link else None)
        c_link.alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
        c_link.border = thin()

        ws4.cell(row=row4, column=6, value=fecha).font = Font(size=7.5, name='Arial')
        ws4.cell(row=row4, column=6).alignment = Alignment(horizontal='center', vertical='center')
        ws4.cell(row=row4, column=6).border = thin()

        ws4.row_dimensions[row4].height = 22
        row4 += 1

    wb.save(outpath)
    print(f'OK:{outpath}')

if __name__ == '__main__':
    data = json.loads(sys.argv[1])
    outpath = sys.argv[2]
    generar(data, outpath)
